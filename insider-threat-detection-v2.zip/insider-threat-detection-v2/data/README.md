Synthetic data is generated automatically by src/main.py.
