from pathlib import Path
import random
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 42
random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR, OUTPUT_DIR = ROOT / 'data', ROOT / 'outputs'
DATA_DIR.mkdir(exist_ok=True); OUTPUT_DIR.mkdir(exist_ok=True)
USERS = ['alice','bob','charlie','david','emma','frank','grace','henry']
NORMAL_EVENTS = ['login','file_open','email_send','file_download']
RISKY_EVENTS = ['usb_usage','large_file_download','file_delete']

def generate_activity_logs(number_of_logs=3000):
    rows=[]
    for _ in range(number_of_logs):
        user=random.choice(USERS); suspicious=random.random()<0.12
        if suspicious:
            event=random.choice(RISKY_EVENTS); hour=random.choice([0,1,2,3,22,23]); bytes_transferred=random.randint(50000,200000)
        else:
            event=random.choice(NORMAL_EVENTS); hour=random.randint(8,18); bytes_transferred=random.randint(0,30000)
        days_ago=random.randint(0,29)
        timestamp=(datetime.now().replace(minute=0,second=0,microsecond=0)-timedelta(days=days_ago)).replace(hour=hour)
        rows.append({'timestamp':timestamp,'user':user,'event':event,'bytes_transferred':bytes_transferred,'label':int(suspicious)})
    return pd.DataFrame(rows)

def build_user_features(logs):
    logs=logs.copy(); logs['timestamp']=pd.to_datetime(logs['timestamp']); logs['date']=logs['timestamp'].dt.date; logs['hour']=logs['timestamp'].dt.hour
    logs['off_hours']=((logs['hour']<8)|(logs['hour']>18)).astype(int)
    logs['risky_event']=logs['event'].isin(RISKY_EVENTS).astype(int)
    return logs.groupby(['user','date']).agg(total_events=('event','size'),unique_event_types=('event','nunique'),total_data_mb=('bytes_transferred',lambda x:x.sum()/(1024*1024)),max_data_mb=('bytes_transferred',lambda x:x.max()/(1024*1024)),off_hours_activity=('off_hours','sum'),risky_event_count=('risky_event','sum'),actual_label=('label','max')).reset_index()

def add_behaviour_baselines(features):
    features=features.copy(); baseline=features.groupby('user').agg(avg_events=('total_events','mean'),avg_data_mb=('total_data_mb','mean'),avg_off_hours=('off_hours_activity','mean')).reset_index(); features=features.merge(baseline,on='user',how='left')
    features['event_deviation']=features['total_events']-features['avg_events']; features['data_deviation']=features['total_data_mb']-features['avg_data_mb']; features['off_hours_deviation']=features['off_hours_activity']-features['avg_off_hours']
    return features

def detect_anomalies(features):
    cols=['total_events','unique_event_types','total_data_mb','max_data_mb','off_hours_activity','risky_event_count','event_deviation','data_deviation']
    X=StandardScaler().fit_transform(features[cols]); detector=IsolationForest(n_estimators=150,contamination=0.12,random_state=RANDOM_STATE)
    result=features.copy(); result['anomaly']=detector.fit_predict(X); result['risk_score']=-detector.decision_function(X)
    lo,hi=result['risk_score'].min(),result['risk_score'].max(); result['risk_score']=0 if hi==lo else (result['risk_score']-lo)/(hi-lo)*100
    result['risk_level']=pd.cut(result['risk_score'],bins=[-1,40,70,100],labels=['Normal','Medium','High'])
    return result

def train_random_forest(features):
    cols=['total_events','unique_event_types','total_data_mb','max_data_mb','off_hours_activity','risky_event_count','event_deviation','data_deviation']; X=features[cols]; y=features['actual_label']
    if y.nunique()<2: return
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.30,random_state=RANDOM_STATE,stratify=y)
    model=RandomForestClassifier(n_estimators=150,random_state=RANDOM_STATE,class_weight='balanced'); model.fit(X_train,y_train); pred=model.predict(X_test)
    print(f'\nRandom Forest Accuracy: {accuracy_score(y_test,pred):.2%}'); print(classification_report(y_test,pred,zero_division=0))
    importance=pd.Series(model.feature_importances_,index=cols).sort_values(); plt.figure(figsize=(9,5)); importance.plot(kind='barh'); plt.title('Important Behavioural Features'); plt.xlabel('Feature Importance'); plt.tight_layout(); plt.savefig(OUTPUT_DIR/'feature_importance.png',dpi=150); plt.close()

def save_results(result):
    result=result.sort_values('risk_score',ascending=False); result.to_csv(OUTPUT_DIR/'user_risk_report.csv',index=False); result[result['risk_level']=='High'].to_csv(OUTPUT_DIR/'high_risk_alerts.csv',index=False)
    counts=result['risk_level'].value_counts().reindex(['Normal','Medium','High'],fill_value=0); plt.figure(figsize=(7,5)); counts.plot(kind='bar'); plt.title('User Risk Level Distribution'); plt.xlabel('Risk Level'); plt.ylabel('Number of Profiles'); plt.xticks(rotation=0); plt.tight_layout(); plt.savefig(OUTPUT_DIR/'risk_distribution.png',dpi=150); plt.close()
    top=result.head(15).sort_values('risk_score'); plt.figure(figsize=(9,6)); plt.barh(top['user'].astype(str)+' - '+top['date'].astype(str),top['risk_score']); plt.title('Top User Risk Scores'); plt.xlabel('Risk Score (0-100)'); plt.tight_layout(); plt.savefig(OUTPUT_DIR/'top_risk_scores.png',dpi=150); plt.close()

def main():
    print('='*60); print('INSIDER THREAT DETECTION SYSTEM'); print('User Behaviour Analytics + Machine Learning'); print('='*60)
    print('\n[1/6] Generating synthetic activity logs...'); logs=generate_activity_logs(); logs.to_csv(DATA_DIR/'synthetic_user_activity.csv',index=False)
    print('[2/6] Building behavioural features...'); features=build_user_features(logs)
    print('[3/6] Calculating user behaviour baselines...'); features=add_behaviour_baselines(features); features.to_csv(DATA_DIR/'user_daily_features.csv',index=False)
    print('[4/6] Detecting anomalies with Isolation Forest...'); result=detect_anomalies(features)
    print('[5/6] Training Random Forest for comparison...'); train_random_forest(result)
    print('[6/6] Saving reports and visualizations...'); save_results(result)
    print('\n===== HIGH-RISK ALERTS ====='); alerts=result[result['risk_level']=='High'][['user','date','risk_score','risk_level','risky_event_count','off_hours_activity']].head(10); print(alerts.to_string(index=False) if not alerts.empty else 'No high-risk profiles detected.')
    print('\nProject completed successfully. Check the outputs folder.')

if __name__=='__main__': main()
