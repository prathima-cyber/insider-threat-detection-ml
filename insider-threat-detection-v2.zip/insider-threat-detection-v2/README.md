# Insider Threat Detection Using User Behaviour Analytics & Machine Learning

A cybersecurity project that analyzes user activity logs, builds behavioural profiles, detects anomalies, and assigns risk levels.

## Modifications made
- Added off-hours activity and risky-event features.
- Added per-user behavioural baselines and deviation scores.
- Added Isolation Forest for unsupervised anomaly detection.
- Added Random Forest for supervised comparison.
- Added 0–100 explainable risk scoring with Normal/Medium/High levels.
- Added risk-distribution, top-risk, and feature-importance charts.

## Technologies
Python | Pandas | NumPy | Scikit-learn | Matplotlib

## Run
```bash
pip install -r requirements.txt
python src/main.py
```

Results are saved in `outputs/`.

## Flow
User Activity Logs → Preprocessing → Feature Engineering → User Baselines → Isolation Forest → Risk Score → Alerts → Visualization

> Synthetic data is used for academic demonstration. Do not use real employee data without authorization, privacy controls, and applicable compliance review.
